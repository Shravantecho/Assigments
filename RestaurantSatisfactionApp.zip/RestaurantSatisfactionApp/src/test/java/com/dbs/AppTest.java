package com.dbs;

import static org.junit.Assert.assertEquals;
import java.io.IOException;
import org.junit.Test;

import com.dbs.App;
import com.dbs.Menu;


public class AppTest {

	@Test
	public void testCreateMenu() throws IOException
	{	
		App app=new App();
		Menu menu=app.createMenu();
		assertEquals(menu.getNoOfItemsInMenu(),menu.getFoodItems().size());
	}
}
