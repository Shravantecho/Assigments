package com.dbs;

import java.util.List;

public class Menu {
	private List<Food> foodItems;
	private int totalTime;
	private int noOfItemsInMenu;
	public Menu(List<Food> foodItems, int totalTime, int noOfItemsInMenu) {
		if(totalTime<=0 || noOfItemsInMenu<=0){
			throw new IllegalArgumentException();
		}
		this.foodItems = foodItems;
		this.totalTime = totalTime;
		this.noOfItemsInMenu = noOfItemsInMenu;
	}
	public List<Food> getFoodItems() {
		return foodItems;
	}
	public int getTotalTime() {
		return totalTime;
	}
	public int getNoOfItemsInMenu() {
		return noOfItemsInMenu;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Menu [foodItems=").append(foodItems).append(", totalTime=").append(totalTime)
				.append(", noOfItemsInMenu=").append(noOfItemsInMenu).append("]");
		return builder.toString();
	}
	
}
