package com.dbs;

import java.math.BigDecimal;

public class Food {
	private long satisfaction;
	private int time;
	
	public Food(long satisfaction, int time) {
		if(satisfaction<=0 || time<=0){
			throw new IllegalArgumentException();
		}
		this.satisfaction = satisfaction;
		this.time = time;
	}
	public long getSatisfaction() {
		return satisfaction;
	}
	public int getTime() {
		return time;
	}
	public BigDecimal ratio(){
		return new BigDecimal(satisfaction/this.time);
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Food [satisfaction=").append(satisfaction).append(", time=").append(time).append("]");
		return builder.toString();
	}
	
}
