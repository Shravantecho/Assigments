package com.dbs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author Arghya
 * 
 * Running this class prints maximum satisfaction in console
 *
 */
public class App 
{
	public static void main( String[] args )
	{
		App app=new App();
		try {
			Menu menu=app.createMenu();
			System.out.println(app.findMaxSatisfaction(menu));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**Finds maximum satisfaction for a given foodItems in
	 * a restaurant menu
	 * 
	 * @param menu the menu which contains food items
	 * @return maximum satisfaction
	 */
	long findMaxSatisfaction(Menu menu) {
		
		Collections.sort(menu.getFoodItems(),Collections.reverseOrder((f1, f2) -> {
			return f1.ratio().compareTo(f2.ratio());
		}));
		int totalTime=0;
		long sumOfSatisfaction=0;
		
		for (Food food : menu.getFoodItems()) {
			
			//At the end we can skip few items which has time more than
			//remaining time to achieve better satisfaction
			
			if(food.getTime()>(menu.getTotalTime()-totalTime)){
				continue;
			}
			totalTime+=food.getTime();
			sumOfSatisfaction+=food.getSatisfaction();
			if(totalTime>=menu.getTotalTime()){
				break;
			}
		}
		return sumOfSatisfaction;
	}

	/**Parses input file and stores the data in menu object
	 * 
	 * @return menu with data from input text file
	 * @throws IOException if any problem while reading file from file system
	 */
	Menu createMenu() throws IOException{
		int totalTime=0;
		int itemsInMenu=0;
		List<Food> foodList=new ArrayList<>();
		try(BufferedReader br = new BufferedReader(new InputStreamReader(
				this.getClass().getResourceAsStream("/data.txt"))))
		{	
			String firstLine = br.readLine();
			String[] array=firstLine.split(" ");
			totalTime=Integer.parseInt(array[0]);
			itemsInMenu=Integer.parseInt(array[1]);
			for(String line; (line = br.readLine()) != null; ){
				String[] splitted=line.split(" ");
				long satisfaction=Long.parseLong(splitted[0]);
				int time=Integer.parseInt(splitted[1]);
				foodList.add(new Food(satisfaction,time));
			}
		}
		return new Menu(foodList,totalTime,itemsInMenu);

	}
}
